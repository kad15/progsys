#ifndef TD9_H
#define TD9_H


#define PORT_SERVEUR 9000
#define BUF_SIZE 512

#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <sys/param.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>



#endif





